import os
import numpy as np
current_dir = os.getcwd()
print(f"現在の作業ディレクトリ: {current_dir}")


f = open('data.py', 'rb')
byteSize = 4
data = f.read(byteSize).hex()

print(list(data))
length=len(data)
new=[]
for i in range (length):
    new.append(int(data[i],16))
#    data[i] =  format(data[i], 'x')
print(list(new))
zero = None
one = None
two = None
three = None
four = None
five = None
six = None
seven = None
eight = None
nine= None
ten = None
elev = None
twelv = None
thirt = None
fourt= None
fift = None
for i in range (byteSize*2):
    if new[i]==0:
        if zero == None:
            zero = []
        zero = zero.append(i)
        print(f'0のデータが{i}で入りました',i)
    elif new[i]==1:
        if one == None:
            one = []
        one = one.append(i)
        print(f'1のデータが{i}で入りました',i)
    elif new[i]==2:
        if two == None:
            two = []
        two = two.append(i)
        print(f'2のデータが{i}で入りました',i)
    elif new[i]==3:
        if three == None:
            three = []
        three = three.append(i)
        print(f'3のデータが{i}で入りました',i)
    elif new[i]==4:
        if four == None:
            four = []
        four = four.append(i)
        print(f'4のデータが{i}で入りました',i)
    elif new[i]==5:
        if five == None:
            five = []
        five = five.append(i)
        print(f'5のデータが{i}で入りました',i)
    elif new[i]==6:
        if six == None:
            six == []
        six = six.append(i)
        print(f'6のデータが{i}で入りました',i)
    elif new[i]==7:
        if seven == None:
            seven == []
        seven = seven.append(i)
        print(f'7のデータが{i}で入りました',i)
    elif new[i]==8:
        if eight == None:
            eight = []
        eight = eight.append(i)
        print(f'8のデータが{i}で入りました',i)
    elif new[i]==9:
        if nine == None:
            nine = []
        nine = nine.append(i)
        print(f'9のデータが{i}で入りました',i)
    elif new[i]==10:
        if ten == None:
            ten = []
        ten = ten.append(i)
        print(f'10のデータが{i}で入りました',i)
    elif new[i]==0x0a:
        if elev == None:
            elev = []
        elev = elev.append(i)
        print(f'aのデータが{i}で入りました',i)
    elif new[i]==0x0b:
        if twelv == None:
            twelv = []
        twelv = twelv.append(i)
        print(f'bのデータが{i}で入りました',i)
    elif new[i]==0x0c:
        if thiet == None:
            thirt = []
        thirt = thirt.append(i)
        print(f'cのデータが{i}で入りました',i)
    elif new[i]==0x0d:
        if fourt == None:
            fourt = []
        fourt = fourt.append(i)
        print(f'dのデータが{i}で入りました',i)
    elif new[i]==0x0e:
        if fift == None:
            fift = []
        fift = fift.append(i)
        print(f'eのデータが{i}で入りました',i)
#index=array[0x00][0]

#print(new[[0][0]]) 
         
print(zero,one,two,three)



f.close()